#include "utilitaire.h"



int main()
{
    Station s{"data_arcs.txt"};
    ///appel de la m�thode pour afficher le graphe
    s.afficher();
}
