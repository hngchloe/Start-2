#ifndef POINT_H
#define POINT_H
#include "utilitaire.h" // inclut l'ensemble des fichiers .h, procedures utilitaires et constantes declarees
                        // necessaires au programme

class Point
{
    private :

    int m_num;          /// ID du Point
    std::string m_nom;  /// Nom du lieu
    int m_altitude;     /// Altitude du Point

    /// Chaque point poss�de la liste de ses successeurs
    /// un vecteur de paires de (pointeur sur Point; dur�e en s)
    std::vector<std::pair<Point*, int> > m_successeurs;

    /// Etat de chaque Point pour les algorithme de parcours
    int m_etat=0; /// 0- NON DECOUVERT    1-DECOUVERT

    /// Stockage du parent dans l'ordre de parcours et de la dur�e en seconde jusqu'au Point initial
    /// un vecteur de paires de (pointeur sur Point;dur�e en s)
    std::pair<Point*,int> m_precedent ={NULL,-1};

    public:

        /// Constructeur / destructeur
        Point(int num,std::string nom,int alt);
        ~Point();

        /// Accesseurs
        int getNum()const ;
        std::string getNom()const;
        int getAltitude()const;
        int getEtat()const;
        std::vector<std::pair<Point*,int>> getSuccesseurs()const;
        std::pair<Point*,int> getPrecedent()const;
        int getPrecedentDuree() const;
        Point* getPrecedentPoint() const;

        /// Accesseur : modifier l'�tat
        void setEtat(int etat);

        /// Accesseur : modifier le precedent dans l'ordre de parcours et la duree totale associee
        void setPrecedent(Point * precedent,int duree);

        /// Methode pour ajouter un successeur � la liste point et duree en s
         void ajouterSucc(Point*p,int duree);

        ///M�thode d'affichage
         void afficher() const ;
};

#endif // POINT_H
