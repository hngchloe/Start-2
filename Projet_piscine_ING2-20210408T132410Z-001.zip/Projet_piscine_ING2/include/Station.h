#ifndef STATION_H
#define STATION_H
#include "utilitaire.h" // inclut l'ensemble des fichiers .h, procedures utilitaires et constantes declarees
                        // necessaires au programme

class Station
{
   private:
   ///liste des Points et des Trajets de la station
    std::vector<Point*> m_points;
    std::vector<Trajet*> m_trajets;
    /// liste des coefficient utilis�s pour calculer les durees pour chaque type de trajet
    std::vector<CoeffsCalculDuree*> m_coeffs_calcul;

    public:
   /// La construction du r�seau se fait � partir d'un fichier
   /// dont le nom est pass� en param�tre
   /// Le fichier contient : / ordre, Id des points, taille, liste des trajets
   Station(std::string nomFichier);
   ~Station();

   /// m�thode d'affichage
   void afficher() const;

   /// methode retourne le point ayant pour identifiant l'id pass� en param�tre
   Point* getPoint(int id);

   /// renvoi le CoeffCalcul Duree dont le type est pass� en param�tre
   CoeffsCalculDuree * getCoeffsCalcul(std::string type);
};

#endif // STATION_H
