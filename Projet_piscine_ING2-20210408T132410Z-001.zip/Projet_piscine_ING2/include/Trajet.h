#ifndef TRAJET_H
#define TRAJET_H
#include "utilitaire.h" // inclut l'ensemble des fichiers .h, procedures utilitaires et constantes declarees
                        // necessaires au programme

class Trajet
{
    private:

        int m_num;
        std::string m_nom;
        std::string m_type;
        //=enum{TK,TS,TSD,TC,TPH,BUS,V,B,R,N,KL,SURF};

        int m_id_PT1;
        int m_id_PT2;
        int m_duree;


    public:
        /// Constructeur / destructeur
        Trajet(int num,std::string nom,std::string type,int id1,int id2);
        ~Trajet();

        /// Accesseurs
        int getNum()const ;
        std::string getNom()const;
        std::string getType()const;
        int getPT1()const;
        int getPT2()const;
        int getDuree()const;

         /// Accesseur : modifier la duree
        void setDuree(int duree);
        /// Methode de calcul de dur�e d'un trajet
        void CalculDuree(int tps_fixe, int coeff,Point *p1, Point *p2);
};

#endif // TRAJET_H
