#ifndef COEFFSCALCULDUREE_H
#define COEFFSCALCULDUREE_H
#include "utilitaire.h" // inclut l'ensemble des fichiers .h, procedures utilitaires et constantes declarees
                        // necessaires au programme

class CoeffsCalculDuree
{
    private:
        std::string m_type;
        int         m_tps_fixe;
        int         m_coeff;

    public:
        CoeffsCalculDuree(std::string type,int tps_fixe,int coeff);
        ~CoeffsCalculDuree();

        /// Accesseurs
        std::string getType()const;
        int getTpsfixe()const;
        int getCoeff()const;
};

#endif // COEFFSCALCULDUREE_H
