#include "utilitaire.h"

/// Constructeur / Destructeur

Trajet::Trajet(int num,std::string nom,std::string type,int id1,int id2)
       :m_num(num),m_nom(nom),m_type(type),m_id_PT1(id1),m_id_PT2(id2),m_duree(0)
{
    //ctor
}

Trajet::~Trajet()
{
    //dtor
}

/// Accesseurs
int Trajet::getNum()const
{
    return m_num;
}
std::string Trajet::getNom()const
{
    return m_nom;
}
std::string Trajet::getType()const
{
    return m_type;
}
int Trajet::getPT1()const
{
    return m_id_PT1;
}
int Trajet::getPT2()const
{
    return m_id_PT2;
}
int Trajet::getDuree()const
{
    return m_duree;
}

/// Accesseur : modifier la duree
void Trajet::setDuree(int duree)
{
    m_duree=duree;
}

/// Methode de calcul de dur�e d'un trajet
void Trajet::CalculDuree(int tps_fixe, int coeff,Point * p1, Point *p2){

    int duree,denivele;


    if (p1->getAltitude()>= p2->getAltitude()) denivele=p1->getAltitude()-p2->getAltitude();
    else denivele=p2->getAltitude()-p1->getAltitude();

    duree= tps_fixe + coeff*denivele/100;
    setDuree(duree);
}
