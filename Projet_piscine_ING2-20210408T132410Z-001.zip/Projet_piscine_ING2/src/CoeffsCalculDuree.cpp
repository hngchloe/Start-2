#include "utilitaire.h" // inclut l'ensemble des fichiers .h, procedures utilitaires et constantes declarees
                        // necessaires au programme
CoeffsCalculDuree::CoeffsCalculDuree(std::string type,int tps_fixe,int coeff)
                  :m_type(type),m_tps_fixe(tps_fixe),m_coeff(coeff)
{
    //ctor
}

CoeffsCalculDuree::~CoeffsCalculDuree()
{
    //dtor
}


std::string CoeffsCalculDuree::getType()const
{
        return m_type;
}
int CoeffsCalculDuree::getTpsfixe()const
{
        return m_tps_fixe;
}
int CoeffsCalculDuree::getCoeff()const
{
        return m_coeff;
}
