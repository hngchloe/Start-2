#include "utilitaire.h"

/// Constructeur / Destructeur

Point::Point(int num,std::string nom,int alt)
      :m_num(num),m_nom(nom),m_altitude(alt)
{

}
Point::~Point()
{
  for (auto s : m_successeurs)
    delete s.first;
}

/// Accesseurs
int Point::getNum()const
{
        return m_num;
}
std::string Point::getNom()const
{
        return m_nom;
}
int Point::getAltitude()const
{
        return m_altitude;
}
int Point::getEtat()const
{
        return m_etat;
}

/// Accesseur : modifier l'�tat
void Point::setEtat(int etat)
{
        m_etat = etat;
}

/// Accesseur : pour la liste des successeurs
std::vector<std::pair<Point*,int>>  Point::getSuccesseurs()const
{
        return m_successeurs;
}
/// Accesseurs : r�cup�rer le precedent dans l'ordre de parcours et la dur�e de trajet associ�e
std::pair<Point*,int> Point::getPrecedent()const
{
    return m_precedent;
}
///Accesseurs : r�cup�rer la duree jusqu'au point initial
int Point::getPrecedentDuree() const
{
    return m_precedent.second;
}
///Accesseurs : r�cup�rer le Point precedent dans l'ordre de parcours
Point* Point::getPrecedentPoint() const
{
    return m_precedent.first;
}

/// Accesseur : modifier le precedent dans l'ordre de parcours
void Point::setPrecedent(Point * precedent,int duree)
{
    m_precedent= std::make_pair(precedent,duree);
}

/// Methode pour ajouter un successeur � la liste ; id du point et duree en s
void Point::ajouterSucc(Point*p,int duree)
{
    m_successeurs.push_back(std::make_pair(p,duree));
}

///M�thode d'affichage
void Point::afficher() const
{
    std::cout<<"Point "<<m_num<<"  Nom : " <<m_nom << "  Altitude : " <<m_altitude ;
    std::cout<<"   Successeurs : ";
    for (auto s : m_successeurs){
        std::cout<<s.first->getNom();    /// affichage du nom du Point au bout de l'arc
        std::cout<<"("<<s.second<<") ";  /// affichage de la duree pour y aller
    }
}
