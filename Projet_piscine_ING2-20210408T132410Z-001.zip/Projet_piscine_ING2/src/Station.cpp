#include "utilitaire.h"

Station::Station(std::string nomFichier)
{
/// La construction du r�seau peut se faire � partir d'un fichier
/// dont le nom est pass� en param�tre
/// Le fichier contient : / ordre, Iid des sommets, taille, liste des arcs
    std::ifstream ifs{nomFichier};
    if (!ifs)
        throw std::runtime_error( "Impossible d'ouvrir en lecture " + nomFichier );

    int ordre;
    ifs >> ordre;
    if ( ifs.fail() )
        throw std::runtime_error("Probleme lecture ordre du graphe");

    int id,alt,i;
    std::string nom;
    for (i=0;i<ordre;i++){
        ifs >>id>>nom>>alt;
        if ( ifs.fail() )
            throw std::runtime_error("Probleme informations point du graphe");
        m_points.push_back( new Point{id,nom,alt} );
    }

    int taille;
    ifs >> taille;
    if ( ifs.fail() )
        throw std::runtime_error("Probleme lecture taille du graphe");

    int num,id_pt1,id_pt2;
    std::string type;
    for (int i=0; i<taille; ++i)
    {
        ifs>>num>>nom>>type>>id_pt1>>id_pt2;
        if ( ifs.fail() )
            throw std::runtime_error("Probleme lecture trajet");
        m_trajets.push_back( new Trajet{id,nom,type,id_pt1,id_pt2} );

    }

    /// chargement de tous les coeffs de calcul des temps de trajet
    int nb_type,tps_fixe,coeff;
    ifs >> nb_type;
    if ( ifs.fail() )
        throw std::runtime_error("Probleme lecture nb de type trajet");
    for (int i=0; i<nb_type; ++i)
    {
        ifs>>type>>tps_fixe>>coeff;
        if ( ifs.fail() )
            throw std::runtime_error("Probleme lecture coeffs");
        m_coeffs_calcul.push_back( new CoeffsCalculDuree{type,tps_fixe,coeff});

    }

    /// a transformer en methode : calcul de tous les temps de trajets
    for (auto t : m_trajets){
        CoeffsCalculDuree *c;
        Point *p1,*p2;
        c=getCoeffsCalcul(t->getType());
        p1=getPoint(t->getPT1());
        p2=getPoint(t->getPT2());
        if (c!=NULL) t->CalculDuree(c->getTpsfixe(),c->getCoeff(),p1,p2);

    }

    /// Creation des listes de successeurs correspondants aux trajets charg�s
    for (auto t : m_trajets){
        Point *p1,*p2;
        p1=getPoint(t->getPT1());
        p2=getPoint(t->getPT2());
        p1->ajouterSucc(p2,t->getDuree());
    }

}

///    destructeur


Station::~Station()
{
   for (auto p : m_points)
        delete p;
   for (auto t : m_trajets)
        delete t;
}

/// m�thode d'affichage
void Station::afficher() const
{
    std::cout<<std::endl<<"Description de la station des Arcs:";
    std::cout<<std::endl<<"Nb de points accessibles = "<<m_points.size()<<std::endl;
    std::cout<<"listes des trajets possibles depuis ces points :"<<std::endl;
    for (auto p : m_points)
    {
        p->afficher();
        std::cout<<std::endl;
    }
}

/// Accesseur : renvoi le point dont l'indice est pass� en param�tre
Point * Station::getPoint(int i)
{
        return m_points[i-1];
}

/// Accesseur : renvoi le CoeffCalcul Duree dont le type est pass� en param�tre
CoeffsCalculDuree * Station::getCoeffsCalcul(std::string type)
{
       int i;
      for (i=0;i<m_coeffs_calcul.size();i++){
        if (type==m_coeffs_calcul[i]->getType()) return m_coeffs_calcul[i];
      }
      return NULL;
}
